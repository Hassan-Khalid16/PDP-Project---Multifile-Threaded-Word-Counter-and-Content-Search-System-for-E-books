import os
import pandas as pd
from PyPDF2 import PdfReader
from docx import Document
import time

class FileHandler:
    """Handles loading and preprocessing of files."""
    
    @staticmethod
    def load_files(directory):
        """Loads all supported files from the given directory."""
        return [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith(('.txt', '.docx', '.pdf'))]

    @staticmethod
    def preprocess(file_path):
        """Extracts text and its context based on file type."""
        try:
            if file_path.endswith('.txt'):
                with open(file_path, 'r', encoding='utf-8') as file:
                    return file.readlines()  # Return lines for locating content
            elif file_path.endswith('.docx'):
                doc = Document(file_path)
                return [para.text for para in doc.paragraphs if para.text.strip()]  # Paragraphs
            elif file_path.endswith('.pdf'):
                reader = PdfReader(file_path)
                return [page.extract_text() for page in reader.pages if page.extract_text()]  # Pages
        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            return []

class LinearProcessor:
    """Implements linear processing for word counting and content search."""
    
    @staticmethod
    def count_words(content):
        """Counts words in the given content."""
        return sum(len(line.split()) for line in content)

    @staticmethod
    def search_content(content, search_text):
        """Searches for specific content in the file."""
        results = []
        for i, line in enumerate(content):
            if search_text.lower() in line.lower():
                snippet_start = max(0, line.lower().find(search_text.lower()) - 50)
                snippet_end = snippet_start + len(search_text) + 100
                snippet = line[snippet_start:snippet_end]
                results.append((i + 1, snippet.strip()))
        return results

def main():
    # Define the directory containing files
    directory = r"C:\Users\hassa\OneDrive - Higher Education Commission\Desktop\PDC PROJECT\DB"
    files = FileHandler.load_files(directory)

    if not files:
        print("No supported files found in the specified directory.")
        return

    # Input the content to search for
    search_text = input("Enter the content (multiple lines or text) to search for: ").strip()
    if not search_text:
        print("You must enter content to search for.")
        return

    print("\nProcessing files linearly...\n")
    start_time = time.time()

    word_counts = {}
    search_results = []
    for file_path in files:
        content = FileHandler.preprocess(file_path)
        word_counts[file_path] = LinearProcessor.count_words(content)
        matches = LinearProcessor.search_content(content, search_text)

        # Add detailed results for each match
        for location, snippet in matches:
            file_type = "Page" if file_path.endswith(".pdf") else ("Paragraph" if file_path.endswith(".docx") else "Line")
            search_results.append({"File": file_path, "Location Type": file_type, "Location": location, "Snippet": snippet})

    elapsed_time = time.time() - start_time
    print(f"\nLinear Processing Completed in {elapsed_time:.2f} seconds")

    # Save word counts to a CSV file
    word_counts_df = pd.DataFrame(list(word_counts.items()), columns=["File", "Word Count"])
    word_counts_df.to_csv("linear_word_counts.csv", index=False)
    print("Word counts saved to linear_word_counts.csv")

    # Save search results to a CSV file
    if search_results:
        search_results_df = pd.DataFrame(search_results)
        search_results_df.to_csv("linear_search_results.csv", index=False)
        print("Search results saved to linear_search_results.csv")
    else:
        print("No files contained the specified content.")

if __name__ == "__main__":
    main()
