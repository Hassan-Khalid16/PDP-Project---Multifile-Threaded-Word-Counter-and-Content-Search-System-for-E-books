import os
import pandas as pd
from PyPDF2 import PdfReader
from docx import Document
from multiprocessing import Pool, cpu_count
import time

class FileHandler:
    """Handles loading and preprocessing of files."""
    
    @staticmethod
    def load_files(directory):
        """Loads all supported files from the given directory."""
        return [os.path.join(directory, f) for f in os.listdir(directory) if f.endswith(('.txt', '.docx', '.pdf'))]

    @staticmethod
    def preprocess(file_path):
        """Extracts text and its context based on file type."""
        try:
            if file_path.endswith('.txt'):
                with open(file_path, 'r', encoding='utf-8') as file:
                    return file.readlines()  # Return lines for locating content
            elif file_path.endswith('.docx'):
                doc = Document(file_path)
                return [para.text for para in doc.paragraphs if para.text.strip()]  # Paragraphs
            elif file_path.endswith('.pdf'):
                reader = PdfReader(file_path)
                return [page.extract_text() for page in reader.pages if page.extract_text()]  # Pages
        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            return []

class ParallelProcessor:
    """Implements parallel processing for word counting and content search."""
    
    @staticmethod
    def count_words(content):
        """Counts words in the given content."""
        return sum(len(line.split()) for line in content)

    @staticmethod
    def search_content(content, search_text):
        """Searches for specific content in the file."""
        results = []
        for i, line in enumerate(content):
            if search_text.lower() in line.lower():
                snippet_start = max(0, line.lower().find(search_text.lower()) - 50)
                snippet_end = snippet_start + len(search_text) + 100
                snippet = line[snippet_start:snippet_end]
                results.append((i + 1, snippet.strip()))
        return results

    @staticmethod
    def process_file(file_path, search_text):
        """Processes a single file for word count and content search."""
        content = FileHandler.preprocess(file_path)
        word_count = ParallelProcessor.count_words(content)
        matches = ParallelProcessor.search_content(content, search_text)
        results = []
        for location, snippet in matches:
            file_type = "Page" if file_path.endswith(".pdf") else ("Paragraph" if file_path.endswith(".docx") else "Line")
            results.append({"File": file_path, "Location Type": file_type, "Location": location, "Snippet": snippet})
        return file_path, word_count, results

def main():
    # Define the directory containing files
    directory = r"C:\Users\hassa\OneDrive - Higher Education Commission\Desktop\PDC PROJECT\DB"
    files = FileHandler.load_files(directory)

    if not files:
        print("No supported files found in the specified directory.")
        return

    # Input the content to search for
    search_text = input("Enter the content (multiple lines or text) to search for: ").strip()
    if not search_text:
        print("You must enter content to search for.")
        return

    print("\nProcessing files in parallel...\n")
    start_time = time.time()

    with Pool(cpu_count()) as pool:
        results = pool.starmap(ParallelProcessor.process_file, [(file, search_text) for file in files])

    elapsed_time = time.time() - start_time
    print(f"\nParallel Processing Completed in {elapsed_time:.2f} seconds")

    # Save word counts to a CSV file
    word_counts = {file: count for file, count, _ in results}
    word_counts_df = pd.DataFrame(list(word_counts.items()), columns=["File", "Word Count"])
    word_counts_df.to_csv("parallel_word_counts.csv", index=False)
    print("Word counts saved to parallel_word_counts.csv")

    # Combine all search results
    search_results = [result for _, _, sublist in results for result in sublist]

    # Save search results to a CSV file
    if search_results:
        search_results_df = pd.DataFrame(search_results)
        search_results_df.to_csv("parallel_search_results.csv", index=False)
        print("Search results saved to parallel_search_results.csv")
    else:
        print("No files contained the specified content.")

if __name__ == "__main__":
    main()
